SKIPMOUNT=false
AUTOMOUNT=true
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

print_modname() {
 ui_print "#########################"
 ui_print "- 模块: $MODNAME"
 ui_print "- 模块ID: $MODID"
 ui_print "- 模块版本: $MODversion"
 ui_print "- 作者: $MODAUTHOR"
 ui_print "- 说明: $MODdescription"
 ui_print "#########################"
 ui_print "- 设备相关信息↓"
 ui_print "- SDK: $SDK"
 ui_print "- 设备: $Device"
 ui_print "- 设备代号: $device"
 ui_print "- 安卓版本: Android $Android"
 ui_print "- MIUI版本: $MIUI  $Version"
 ui_print "#########################"
}

on_install() {
# 系统版本检测
 if [ $device = "mona" ];then : 
 else ui_print "- 你的设备机型不符合本模块运行条件" && abort; fi
 if [ $Android = "12" ];then :
 else ui_print "- 设备支持安装, 模块正在执行 -" 
 ui_print " "
 ui_print "- 解包模块文件 -"
 ui_print " " 
# 解包模块文件 
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 sleep 1.6
 rm -rf $MODPATH/system/product/
 ui_print "- 解包完毕 -"
 ui_print " "
# 打印时间 
 description=$MODPATH/module.prop
 time0=$(date "+%Y-%m-%d %H:%M")
 echo "- 当前时间: $time0"
 echo "$time0" >> $MODULE
 sleep 1.6; fi 
 ui_print "- 设备支持安装, 模块正在执行 -"
 ui_print " "
 ui_print "- 解包模块文件 -"
 ui_print " " 
# 解包模块文件 
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 sleep 1.6
 rm -rf $MODPATH/system/vendor/
 ui_print "- 解包完毕 -"
 ui_print " "
# 打印时间 
 description=$MODPATH/module.prop
 time0=$(date "+%Y-%m-%d %H:%M")
 echo "- 当前时间: $time0"
 echo "$time0" >> $MODULE
 sleep 1.6 
}

# 设置文件权限
set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  chmod -R 755 $MODPATH
}